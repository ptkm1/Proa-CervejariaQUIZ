const theme = {
  colors: {
    background: '#f9f9f9',
    text: '#e1e1e6',
    primary: '#64358C'
  }
}

export default theme
