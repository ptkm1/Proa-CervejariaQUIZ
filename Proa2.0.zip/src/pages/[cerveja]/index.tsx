import { useRouter } from 'next/dist/client/router'
import React, { useContext, useEffect, useRef } from 'react'
import VariasCervejas from '../../components/VariasCervejas'
import { Cervejas } from '../../data/mock'
import ToastComponent from '../../components/Toasty'
import { Bottom, BottomItems, CervejaLayout, ImageAndInformations, Informations, Top, TopContent } from '../../styles/pages/CervejaLayout'
import { 
  createMuiTheme,
  responsiveFontSizes,
  MuiThemeProvider,
  Typography
} from '@material-ui/core'
import Barco from '../../assets/barco.png'
import Logo from '../../assets/logo.png'
import { MiddleButton } from '../../styles/pages/Layout'

let theme = createMuiTheme();
theme = responsiveFontSizes(theme)

const CervejaPage: React.FC = () => {
  const {
    query: { cerveja }
  } = useRouter()
  const Router = useRouter()


  return (
    <MuiThemeProvider theme={theme}>
    <CervejaLayout>
      <Top>
        { Cervejas.filter((e: any) => e.titulo === cerveja).map((e: any) => (
          <TopContent>
            <ToastComponent>{e.toast}</ToastComponent>
            <ImageAndInformations>
              <img src={e.img} />
              <Informations>
                <Typography variant="h4">{e.cerveja}</Typography>
                <Typography variant="body1">{e.descricao}</Typography>
                <Typography variant="caption">{e.abv}</Typography>
                <a href="#">Marcar Encontro!</a>
              </Informations>
            </ImageAndInformations>



          </TopContent>
        )) }
      </Top>
      <Bottom>
        <BottomItems>
        <div style={{ display: 'flex', justifyContent: "flex-end" }} >
            <img src={Logo} id="logo" />
          </div>
          <div style={{ display: 'flex', justifyContent: "flex-end" }}>
            <img src={Barco} id="barquinho" />
          </div>
        </BottomItems>
      </Bottom>
    </CervejaLayout>
    </MuiThemeProvider>
  )
}

export default CervejaPage
